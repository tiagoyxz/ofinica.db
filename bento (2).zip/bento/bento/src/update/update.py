import sqlite3  # Importa a biblioteca

# Caminho para o banco de dados
caminho_db = r'C:\\Users\\ba2423\\Downloads\\python-db-with-sqlite3-main\\python-db-with-sqlite3-main\\bento\\bento\\db\\oficina.db'

# Conexão com o banco de dados
conexao = sqlite3.connect(caminho_db)

# Cursor para realizar a operação
cursor = conexao.cursor()

# Atualizando a tabela "carros"
cursor.execute('''
    UPDATE carros
    SET MARCA = ?
    WHERE id = ?
''', ("Ferrari", 1))

# Salva as alterações
conexao.commit()

# Fecha a conexão com o banco de dados
conexao.close()